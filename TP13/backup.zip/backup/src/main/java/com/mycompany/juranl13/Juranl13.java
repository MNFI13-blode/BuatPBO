/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.juranl13;

import config.koneksi;
import java.sql.Connection;

/**
 *
 * @author oyest
 */
public class Juranl13 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Connection conn = koneksi.getConnection();
         if (conn != null) {
            System.out.println("Koneksi ke database berhasil!");
        } else {
            System.out.println("Koneksi ke database gagal.");
        }
    }
}
