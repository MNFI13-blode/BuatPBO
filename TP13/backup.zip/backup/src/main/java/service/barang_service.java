/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;
import model.barang_mod;
import java.sql.SQLException;
import java.util.List;
/**
 *
 * @author oyest
 */
public interface barang_service {
    void addBarang(barang_mod barang) throws SQLException;
    List<barang_mod> getAllBarang() throws SQLException;
    
}
