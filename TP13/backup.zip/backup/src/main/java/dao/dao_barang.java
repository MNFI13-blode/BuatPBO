/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.SQLException;
import java.util.List;
import model.barang_mod;
import service.barang_service;
import java.util.ArrayList;
import config.koneksi;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
/**
 *
 * @author oyest
 */
public class dao_barang implements barang_service{
     private Connection conn;
     
     public  dao_barang(){
         conn = koneksi.getConnection();
     }
    @Override
    public void addBarang(barang_mod barang) throws SQLException {
        String query = "INSERT INTO barang(nama,harga,stok) VALUES(?,?,?)";
        PreparedStatement psmt = conn.prepareStatement(query);
        psmt.setString(1, barang.getNama());
        psmt.setInt(2, barang.getHarga());
        psmt.setInt(3, barang.getStok());
        psmt.executeUpdate();
    }

    @Override
    public List<barang_mod> getAllBarang() throws SQLException {
        String query = "Select * FROM barang";
        PreparedStatement psmt = conn.prepareStatement(query);
        ResultSet rs = psmt.executeQuery();
        List<barang_mod> barang_List = new ArrayList<>();
        while(rs.next()){
            barang_mod jawi = new barang_mod(rs.getInt("id"), rs.getString("nama"),rs.getInt("harga"),rs.getInt("stok"));
            barang_List.add(jawi);
        }
        return barang_List;
    }
    
    
}
